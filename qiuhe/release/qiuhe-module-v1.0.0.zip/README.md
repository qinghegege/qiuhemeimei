## qiuhe 安装说明

### 需求
- Android 设备已 Root
- Magisk Manager 或 KernelSU 管理器
- 已安装对应腾讯手游

### 安装步骤
1. 在管理器中点击「从本地安装」
2. 选择 qiuhe-module-*.zip
3. 刷入后重启
4. 终端输入 `qiuhe` 即可使用

### 数据位置
- 账号存档: /data/adb/qiuhe/data/accounts/
- 切换快照: /data/adb/qiuhe/data/snapshots/
